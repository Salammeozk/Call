from os import getenv
BOT_USERNAME = getenv("BOT_USERNAME", "Li_on_1989bot")
ASSISTANT_NAME = getenv("ASSISTANT_USERNAME", "Li_on_1989bot")
